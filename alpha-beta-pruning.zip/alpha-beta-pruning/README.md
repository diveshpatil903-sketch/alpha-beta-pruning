# Alpha-Beta Pruning in Python

A simple Python implementation of the **Alpha-Beta Pruning** algorithm, an
optimization of the Minimax algorithm used in two-player games.

## What this program does

- Uses a binary game tree with 8 leaf-node values.
- Alternates between MAX and MIN levels.
- Updates the alpha and beta values while searching.
- Skips branches that cannot affect the final decision (pruning).
- Prints the optimal value.

## Requirements

- Python 3.x
- No external libraries are required (`math` is part of Python).

## Run the program

```bash
python alpha_beta_pruning.py
```

## Sample output

```text
Leaf Node Values: [3, 5, 6, 9, 1, 2, 0, -1]
Pruning at MIN node

Optimal Value: 5
```

## Algorithm terms

- **Alpha (α):** Best value MAX can guarantee so far.
- **Beta (β):** Best value MIN can guarantee so far.
- **Pruning:** Stops exploring a branch when `beta <= alpha`.

## Repository structure

```text
alpha-beta-pruning/
├── alpha_beta_pruning.py
├── README.md
└── .gitignore
```

## License

This project is available under the MIT License.
